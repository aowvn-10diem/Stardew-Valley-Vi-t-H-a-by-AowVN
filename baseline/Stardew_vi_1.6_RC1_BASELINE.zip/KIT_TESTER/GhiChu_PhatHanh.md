# Ghi chú phát hành — Stardew Valley Việt hóa, RC1 (09/08/2026)

## Bản này là gì
Bản dịch tiếng Việt **hoàn chỉnh 100% nội dung hiển thị cho người chơi** của Stardew Valley 1.6, thay trực tiếp file nội dung game (không cần mod loader). Đây là bản **Release Candidate 1** — đã qua vòng rà soát kỹ thuật toàn diện, chỉ chờ playtest thực tế trước khi phát hành chính thức.

## Phạm vi đã dịch (238 file tiếng Việt)
- Toàn bộ thoại NPC: 12 nhân vật hẹn hò/cưới được + dân thị trấn, gồm cả thoại hôn nhân.
- Toàn bộ 43 file sự kiện/cutscene (khoảng 1.700 đoạn thoại).
- Lễ hội, thư từ (mail), nhiệm vụ (quest), ghi chú bí mật, đơn đặt hàng đặc biệt.
- Giao diện (menu chính, tạo nhân vật, túi đồ, tooltip, tùy chọn), tên vật phẩm/công cụ/trang phục/công trình, thành tựu, kênh TV, màn hình credits (có mục riêng "Bản Việt hóa (AowVN)").

## Những gì mới ở RC1 (so với các bản thử nội bộ)
- Sửa 931 trường kỹ thuật bị dịch nhầm (Season/Type/Id/Weather...) — lỗi có nguy cơ phá hệ thống game, đã dứt điểm.
- Sửa 7 khoá thư bị lỗi hiển thị song ngữ; khôi phục 862 trường kỹ thuật khác; chuẩn hóa hàng loạt tên khoáng vật, thuật ngữ.
- Rà soát tràn khung: rút gọn các nhãn nút/tên vật phẩm quá dài; xác nhận toàn bộ hội thoại trong giới hạn hiển thị của engine.
- Dịch đầy đủ hệ thống câu ghép ngẫu nhiên (Mad Libs) sau khi nghiên cứu thuật toán ghép.

## Cố ý giữ nguyên tiếng Anh (không phải sót dịch)
- Tên thương hiệu/sinh vật trong game: **Joja**, **Junimo**, **Stardrop**, **gridball**, **Stardew** (và "Thung lũng Stardew").
- Tên riêng nhân vật (Pierre, Lewis, Marnie...) và các từ mượn quốc tế phổ biến (Pizza, Sashimi...).
- Một số tên đá quý hiếm khiến cả bản tham chiếu Tây Ban Nha/Đức cũng xử lý không thống nhất (Celestine, Jasper, Opal, Orpiment).

## Phương châm dịch
Khẩu ngữ tự nhiên như người Việt nói thật, giữ trọn chất giọng từng nhân vật (xem phần credits), giữ nguyên bối cảnh phương Tây của thung lũng. Mọi xưng hô đều tự động đúng theo giới tính nhân vật bạn chọn.

## Báo lỗi
Đọc `Mau_BaoLoi.md` để biết cách báo lỗi đúng mẫu (mức A/B/C). Mọi phản hồi được gom ở database Notion của dự án — Aow sẽ gửi link khi mở đợt test.
