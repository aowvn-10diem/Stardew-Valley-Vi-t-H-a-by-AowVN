# Known Issues — RC1 (đã biết, đang theo dõi)

Đây là danh sách các điểm **đã được kiểm tra và cân nhắc** trước khi đóng gói. Nếu bạn gặp đúng các mục này, vẫn cứ báo (giúp xác nhận), nhưng không cần lo — chúng đã có trong tầm kiểm soát.

## 1. Cần tester xác nhận bằng mắt (rủi ro hiển thị, chưa thấy vỡ thật)
Các màn hình thoại dài nhất của bản dịch — đều nằm trong giới hạn engine đã render được ở bản gốc, nhưng nên xác nhận bằng mắt trong game:
- Thoại "hồi ức" của Penny (sau sự kiện 35) — dài ngang bản gốc tiếng Anh.
- Thoại Caroline khi nâng cấp nhà (`houseUpgrade_1`).
- Thoại Jodi ngày thứ Sáu (`Fri`).
- Thoại hôn nhân Emily `Good_5` và Krobus `spouseRoom_Krobus` (văn phong giàu hình ảnh, dài hơn bản gốc có chủ đích).
- 2 tiêu đề tranh/sách nội thất dài ngang bản gốc: "Hành Trình Của Vua Đồng Cỏ: Phiên Bản Điện Ảnh", "Kỳ Quan Thiên Nhiên: Khám Phá Thế Giới Đa Dạng".
- Thoại của vợ/chồng ở các lễ hội năm 2+ và vài câu ở Lễ hội Sa Mạc: 15 câu **đảo thứ tự 2 màn hình thoại** so với bản gốc (nội dung đủ cả hai ý, đã kiểm chứng bằng script) — nếu thấy thứ tự thoại hơi lạ, báo mức C.

## 2. Đã xác nhận không phải lỗi
- Một số tên vật phẩm/tên gói dài hơn tiếng Anh 20–40%: đặc thù tiếng Việt; tooltip trong game tự giãn, không cắt chữ.
- Nhãn chế độ điều khiển trên **mobile** (`Chạm Để Di Chuyển & Cần Điều Khiển...`) dài — bản PC không dùng mục này.
- Một vài câu hội thoại hôn nhân chứa cả hai nhánh xưng hô `${anh^em}$` — game tự chọn đúng nhánh theo giới tính nhân vật, chỉ hiển thị một nhánh khi chơi.

## 3. Kỹ thuật ngầm (không ảnh hưởng trải nghiệm chơi)
- 40 mục trong `Data/Furniture.json` thiếu một trường kỹ thuật `-1` so với bản tham chiếu — tên nội thất vẫn hiển thị đúng; sẽ xử lý ở đợt kỹ thuật riêng.
- Công thức chế tạo "Bệ lửa Đầu Lâu" (Skull Brazier) có danh sách nguyên liệu khác bản tham chiếu cũ — nghi theo phiên bản game mới hơn; đang theo dõi.

## 4. Cố ý giữ nguyên tiếng Anh
Xem mục "Cố ý giữ nguyên tiếng Anh" trong `GhiChu_PhatHanh.md` (Joja, Junimo, Stardrop, gridball, tên riêng...). Đừng báo các mục này là "sót dịch" nhé — nhưng nếu thấy chỗ nào khác còn tiếng Anh, đó là lỗi, hãy báo ngay.
