================================================================
 STARDEW VALLEY TIẾNG VIỆT — BẢN RC1 (Release Candidate 1)
 Hướng dẫn cài đặt cho tester
================================================================

[1] YÊU CẦU
- Stardew Valley bản 1.6.x trên PC (Steam hoặc GOG).
- KHÔNG cần SMAPI — bản dịch này thay trực tiếp file nội dung game.
- Bản dịch dành cho bản 1.6; nếu game của bạn cũ hơn, hãy cập nhật trước.

[2] SAO LƯU TRƯỚC KHI CÀI (bắt buộc, mất 1 phút)
- Sao lưu save: sao chép thư mục  Saves  tại:
    Windows:  %appdata%\StardewValley\Saves
    macOS:    ~/.config/StardewValley/Saves
    Linux:    ~/.config/StardewValley/Saves
- (Khuyến nghị) Sao chép thêm thư mục  Content  gốc của game
  để gỡ bản dịch nhanh mà không cần tải lại.

[3] CÀI ĐẶT
1. Giải nén file stardew_vi_1.6_RC1.zip.
2. Mở thư mục cài game (Steam: chuột phải game → Manage → Browse local files).
3. Sao chép 3 thư mục  Data , Dialogue , Strings  vào trong thư mục
   Content  của game.
4. Chọn "Ghi đè toàn bộ" (Replace all) khi hệ thống hỏi.
5. Mở game và chơi bình thường. Save cũ dùng được bình thường.

[4] GỠ BẢN DỊCH
- Steam: chuột phải game → Properties → Installed Files
  → "Verify integrity of game files".
- GOG: Manage installation → Verify / Repair.
- Hoặc chép lại thư mục Content đã sao lưu ở bước [2].
- Save game KHÔNG bị ảnh hưởng khi cài hay gỡ bản dịch.

[5] LƯU Ý
- Chơi mạng (co-op): tất cả người chơi nên cài cùng một bản dịch.
- Nếu game cập nhật lên bản mới hơn 1.6.x, hãy gỡ bản dịch trước khi
  cập nhật rồi cài lại bản dịch phù hợp.
- Báo lỗi: đọc file  Mau_BaoLoi.md  trong thư mục KIT_TESTER.
- Lộ trình test gợi ý:  HuongDan_Test.md  trong cùng thư mục.
