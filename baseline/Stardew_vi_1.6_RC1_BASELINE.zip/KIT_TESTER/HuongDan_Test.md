# Hướng dẫn test theo tuyến — RC1

Mục tiêu: đi qua những khu vực người chơi gặp sớm nhất và dày nội dung dịch nhất. Không cần chơi hết game — theo tuyến dưới là phủ được phần lớn rủi ro.

## Chặng 1 — 60 phút đầu game mới (quan trọng nhất)
Tạo file save MỚI và chơi như người mới:
1. Menu chính + màn hình tạo nhân vật: đọc kỹ mọi nhãn, tooltip loại nông trại, ô tên "Trang trại {tên}".
2. Cutscene mở đầu + thư của Ông (trong di chúc).
3. Đến nông trại: thoại Robin/Lewis chào đón, hướng dẫn ban đầu.
4. Nhận công cụ từ Willy (cảnh ở bãi biển), nói chuyện Pierre ở cửa hàng.
5. Mở TV (dự báo thời tiết, kênh mẹo), xem thư trong hòm thư, đọc quest đầu tiên.
6. Vào thị trấn nói chuyện 5–10 NPC bất kỳ; để ý lời chào đầu tiên (Introduction).
→ Đây là cụm "1 giờ đầu game" đã được đọc đối chiếu 100%; mọi lỗi ở chặng này đều đáng ngạc nhiên — hãy báo ngay.

## Chặng 2 — Một mùa xuân đầy đủ
- Trồng, tưới, thu hoạch, bán rau củ đầu mùa; đọc mô tả hạt giống trong cửa hàng Pierre và JojaMart.
- Câu cá vài con, vào mỏ đá đánh quái, đọc thông báo lên cấp kỹ năng.
- Đọc thư gửi đến (thư mẹ, thư quà NPC, công thức nấu ăn).
- Tham dự lễ hội **Săn Trứng (ngày 13 xuân)**: nói chuyện hết NPC trong lễ hội.
- Kiểm tra: gói Community Center (Nhà Văn Hóa), bảng đơn đặt hàng, lịch/bảng tin.

## Chặng 3 — Một sự kiện tim (heart event)
Gợi ý cảnh dễ kích hoạt sớm (vào đúng địa điểm/giờ là kích):
- Haley 2 tim (vào nhà khi cô ấy ở nhà), Sam 2 tim (nhà Sam), Sebastian 2 tim (phòng hầm khi cậu ấy online), Abigail 2 tim (phòng Pierre).
→ Trong cảnh, cố ý chọn các **lựa chọn thoại** khác nhau (nếu chơi lại) để kiểm tra hộp lựa chọn và các nhánh rẽ.

## Chặng 4 — Thêm một lễ hội nữa
- Vũ hội Hoa (24 xuân) — thử mời/ bị từ chối khiêu vũ; hoặc tiệc Luau (11 hạ) nếu save đã tới hè: bỏ nguyên liệu vào nồi súp và nghe Ngài Thủ Hiến nhận xét.

## Chặng 5 — Hôn nhân (nếu có save cũ đã cưới hoặc sắp cưới)
- Mua Mặt Dây Chuyền Nàng Tiên Cá (người bán ở bãi biển ngày mưa), cầu hôn, xem lễ cưới.
- Đọc thoại vợ/chồng buổi sáng/tối/mưa/nắng; kiểm tra xưng hô có đúng giới tính nhân vật của bạn không (đây là điểm dịch đặc thù của tiếng Việt).
- Nếu save đã có con: đọc thoại về con (1 con/2 con).

## Những gì cần để mắt khi đi qua bất kỳ đâu
- **Mức A**: chữ lỗi (ô vuông, dấu), mất dòng, game kẹt.
- **B**: sai nghĩa, sai xưng hô, sai tên.
- **C**: chữ tràn khung, câu khó hiểu, chính tả, văn phong chưa hay.
Báo lỗi theo mẫu trong `Mau_BaoLoi.md`. Cảm ơn bạn đã test!
